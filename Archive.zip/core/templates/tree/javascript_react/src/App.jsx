import './App.css'

function App() {
  return (
    <>
      <h1>{{ project_name }}</h1>
    </>
  )
}

export default App
