import './Home.css'

function Home() {
  return (
    <div id="homePage">
      <h1>{{ project_name }}</h1>
    </div>
  )
}

export default Home
