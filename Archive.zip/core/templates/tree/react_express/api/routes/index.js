import { Router } from 'express';

const router = Router();

// Define API routes here
// All API routes must have /api/ prefix to avoid conflicts with the UI/frontend.

export default router;